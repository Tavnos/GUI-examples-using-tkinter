import tkinter as tk
import random as rd

def draw_grid(tk_frame):
    grid_list = tk_frame.grid_dict["grid_list"]
    rows = len(grid_list)
    cols = len(grid_list[0])
    for row in range(rows):
        for col in range(cols):
            left = 5 + col * 30
            right = left + 30
            top = 5 + row * 30
            bottom = top + 30
            tk_frame.create_rectangle(left, top, right, bottom, fill="white") 
            if (grid_list[row][col] > 0):
                tk_frame.create_oval(left, top, right, bottom, fill="blue")
            elif (grid_list[row][col] < 0):
                tk_frame.create_oval(left, top, right, bottom, fill="green")
def render_frame(tk_frame):
    rows = tk_frame.grid_dict["rows"]
    cols = tk_frame.grid_dict["cols"]
    grid_list = [ ]
    for row in range(rows): 
        grid_list += [[0] * cols]
    grid_list[int(rows/2)][int(cols/2)] = 1
    tk_frame.grid_dict["grid_list"] = grid_list
    get_front_pos(tk_frame)
    place_food(tk_frame)
def get_front_pos(tk_frame):
    grid_list = tk_frame.grid_dict["grid_list"]
    for row in range(len(grid_list)): 
        for col in range(len(grid_list[0])):
            if (grid_list[row][col] > 0): #
                head_row = row
                head_col = col
    tk_frame.grid_dict["head_row"] = head_row
    tk_frame.grid_dict["head_col"] = head_col
def place_food(tk_frame):
    grid_list = tk_frame.grid_dict["grid_list"]
    row = rd.randint(0,len(grid_list)-1)
    col = rd.randint(0,len(grid_list[0])-1)
    grid_list[row][col] = -1
def update_snake(tk_frame, dist_row, dist_col):
    tk_frame.grid_dict["vector_row"] = dist_row
    tk_frame.grid_dict["vector_col"] = dist_col
    grid_list = tk_frame.grid_dict["grid_list"]
    head_row = tk_frame.grid_dict["head_row"]
    head_col = tk_frame.grid_dict["head_col"]
    new_head_row = head_row + dist_row
    new_head_col = head_col + dist_col
    if ((new_head_row < 0) or (new_head_row >= len(grid_list)) or
        (new_head_col < 0) or (new_head_col >= len(grid_list[0]))):
        game_over(tk_frame)
    elif (grid_list[new_head_row][new_head_col] > 0):
        game_over(tk_frame)
    elif (grid_list[new_head_row][new_head_col] < 0):
        grid_list[new_head_row][new_head_col] = 1 + grid_list[head_row][head_col];
        tk_frame.grid_dict["head_row"] = new_head_row
        tk_frame.grid_dict["head_col"] = new_head_col
        place_food(tk_frame)
    else:
        grid_list[new_head_row][new_head_col] = 1 + grid_list[head_row][head_col];
        tk_frame.grid_dict["head_row"] = new_head_row
        tk_frame.grid_dict["head_col"] = new_head_col
        grid_list = tk_frame.grid_dict["grid_list"]
        for row in range(len(grid_list)):
            for col in range(len(grid_list[0])):
                if (grid_list[row][col] > 0):
                    grid_list[row][col] -= 1
def timer_clock(tk_frame):
    tk_frame.grid_dict["skip_clock"] = False
    if tk_frame.grid_dict["game_over"] == False:
        dist_row = tk_frame.grid_dict["vector_row"]
        dist_col = tk_frame.grid_dict["vector_col"]
        update_snake(tk_frame, dist_row, dist_col)
        reset_frame(tk_frame)
    delay = 50 # (ms)
    tk_frame.after(delay, timer_clock, tk_frame)
def key_pressed(tk_command):
    tk_frame = tk_command.widget.tk_frame
    tk_frame.grid_dict["skip_clock"] = True
    if (tk_command.char == "r"):
        init(tk_frame)
    if tk_frame.grid_dict["game_over"] == False:
        if (tk_command.keysym == "Up"):
            update_snake(tk_frame, -1, 0)
        elif (tk_command.keysym == "Down"):
            update_snake(tk_frame, +1, 0)
        elif (tk_command.keysym == "Left"):
            update_snake(tk_frame, 0,-1)
        elif (tk_command.keysym == "Right"):
            update_snake(tk_frame, 0,+1)
def init(tk_frame):
    render_frame(tk_frame)
    tk_frame.grid_dict["game_over"] = False
    tk_frame.grid_dict["vector_row"] = 0
    tk_frame.grid_dict["vector_col"] = -1
    tk_frame.grid_dict["skip_clock"] = False
def game_over(tk_frame):
    tk_frame.grid_dict["game_over"] = True
    reset_frame(tk_frame)
def reset_frame(tk_frame):
    tk_frame.delete(tk.ALL)
    draw_grid(tk_frame)
def run(rows, cols):
    tk_root = tk.Tk()
    frame_width = 2*5 + cols*30
    frame_height = 2*5 + rows*30
    tk_frame = tk.Canvas(tk_root, width=frame_width, height=frame_height)
    tk_frame.pack()
    tk_root.tk_frame = tk_frame 
    tk_frame.grid_dict = { }
    tk_frame.grid_dict["frame_width"] = frame_width
    tk_frame.grid_dict["frame_height"] = frame_height
    tk_frame.grid_dict["rows"] = rows
    tk_frame.grid_dict["cols"] = cols
    init(tk_frame)
    tk_root.bind("<Key>", key_pressed)
    timer_clock(tk_frame)
    tk_root.mainloop()
run(15,15)